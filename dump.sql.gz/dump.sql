-- MySQL dump 10.13  Distrib 5.5.52, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: LogDB
-- ------------------------------------------------------
-- Server version	5.5.52-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `LogText` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (1,'[2016-09-25 11:22:06] s:31:\"Im write the log to this table.\";'),(2,'[2016-09-25 11:22:07] s:31:\"Im write the log to this table.\";'),(3,'[2016-09-25 11:22:07] s:31:\"Im write the log to this table.\";'),(4,'[2016-09-25 11:22:07] s:31:\"Im write the log to this table.\";'),(5,'[2016-09-25 11:48:32] s:31:\"Im write the log to this table.\";'),(6,'[2016-09-25 11:49:18] s:31:\"Im write the log to this table.\";'),(7,'[2016-09-25 11:49:26] s:31:\"Im write the log to this table.\";'),(8,'[2016-09-25 12:09:40] s:31:\"Im write the log to this table.\";'),(9,'[2016-09-25 12:27:42] s:31:\"Im write the log to this table.\";'),(10,'[2016-09-25 12:27:42] s:31:\"Im write the log to this table.\";'),(11,'[2016-09-25 12:37:06] s:31:\"Im write the log to this table.\";'),(12,'[2016-09-25 12:37:31] s:31:\"Im write the log to this table.\";'),(13,'[2016-09-25 12:38:44] s:31:\"Im write the log to this table.\";'),(14,'[2016-09-25 12:39:51] s:31:\"Im write the log to this table.\";'),(15,'[2016-09-25 15:05:29] s:31:\"Im write the log to this table.\";'),(16,'[2016-09-25 15:06:08] s:31:\"Im write the log to this table.\";'),(17,'[2016-09-25 15:11:53] s:31:\"Im write the log to this table.\";'),(18,'[2016-09-25 15:15:20] s:31:\"Im write the log to this table.\";'),(19,'[2016-09-25 15:23:52] s:31:\"Im write the log to this table.\";'),(20,'[2016-09-25 15:24:31] s:31:\"Im write the log to this table.\";'),(21,'[2016-09-25 16:17:09] s:31:\"Im write the log to this table.\";'),(22,'[2016-09-25 17:08:58] s:31:\"Im write the log to this table.\";'),(23,'[2016-09-26 14:08:06] 11111111111111'),(24,'[2016-09-26 14:10:01] 11111111111111'),(25,'[2016-09-26 14:10:19] 11111111111111'),(26,'[2016-09-26 14:21:49] 11111111111111'),(27,'[2016-09-26 14:24:31] 11111111111111'),(28,'[2016-09-26 14:34:14] mysql'),(29,'[2016-09-26 14:34:38] mysql'),(30,'[2016-09-26 14:34:50] mysql'),(31,'[2016-09-26 14:55:00] mysql'),(32,'[2016-09-26 15:11:48] mysql'),(33,'[2016-09-26 15:12:05] mysql'),(34,'[2016-09-26 15:12:35] mysql'),(35,'[2016-09-26 19:35:18] mysql'),(36,'[2016-09-26 21:06:12] log text');
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-27 12:34:09
